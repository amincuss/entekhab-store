declare module "stylis";
