import React from 'react'

function UserNotFound() {
  return (
    <div>UserNotFound</div>
  )
}

export default UserNotFound