import GlobalLoading from "@/components/GlobalLoading";


import React from 'react'

function Loading() {
  return (
<GlobalLoading />  )
}

export default Loading