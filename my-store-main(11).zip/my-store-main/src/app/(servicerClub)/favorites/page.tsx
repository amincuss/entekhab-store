
export default async function FavoritesPage() {
  return (
    <div className="h-full flex justify-center items-center">
      <p className="text-gray-500 text-sm">موارد برگزیده ای موجود نیست</p>
    </div>
  );
}
