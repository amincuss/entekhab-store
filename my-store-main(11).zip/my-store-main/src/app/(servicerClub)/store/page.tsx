import StoreView from "@/features/ServicerClub/Components/StoreView";

export default function StorePage() {
  return <StoreView/>;
}
