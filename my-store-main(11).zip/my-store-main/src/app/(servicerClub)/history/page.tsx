import HistoryPage from '@/features/ServicerClub/Components/History/HistoryPage';
import React from 'react'

function historyPage() {
  return <HistoryPage />

}

export default historyPage;