import Profile from "@/features/ServicerClub/Components/Profile";

export default async function ProfilePage() {

  return <Profile />;
}
