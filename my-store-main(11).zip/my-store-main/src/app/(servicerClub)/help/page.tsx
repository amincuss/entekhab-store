import HelpList from "@/features/ServicerClub/Components/Help/HelpList";
import React from "react";

function page() {
  return <HelpList />;
}

export default page;
